/** Automatically generated file. DO NOT MODIFY */
package com.jay.example.viewpagerdemo4;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}